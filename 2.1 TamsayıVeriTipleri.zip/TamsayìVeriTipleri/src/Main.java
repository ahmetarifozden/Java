public class Main {
    
    public static void main(String[] args) {
        // byte --> short --> int --> long
        
        short i = 100;
        byte j = 2;
        int k = 4;
        
        long d = i + j + k;
        System.out.println(d);
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
