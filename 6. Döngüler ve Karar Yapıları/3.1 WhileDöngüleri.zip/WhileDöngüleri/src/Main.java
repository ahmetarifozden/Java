
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        /*
        while(döngü koşulu) {
            // Koşul doğru olduğu sürece çalışır.
        }
        
        */
        /*for (int i = 0;i <10 ; i++) {
            System.out.println("i = " + i);
        }*/
        /*Scanner scanner  = new Scanner(System.in);
        
        System.out.println("Bir sayı giriniz:");
        
        int sayi = scanner.nextInt();
        
        int faktoriyel = 1;
        
        while (sayi > 0){
            
            faktoriyel *= sayi;
            sayi--;
            
        }
        System.out.println("Faktoriyel =" + faktoriyel); */
        
        int i = 0;
        
        while (i < 10 ) {
            
            System.out.println("i = " + i );
            i--;
            
            
        }
        
                
    }
    
}
