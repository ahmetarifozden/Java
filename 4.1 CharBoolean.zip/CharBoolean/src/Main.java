
public class Main {
    public static void main(String[] args) {
        // Char Veri Tipi : Karakterleri göstermek için kullanılır. 2 byte yer kaplar. 2^16 tane karakter simgelenebilir.
        // Boolean Veri Tipi : Koşul Durumlarında kullanılır. true veya false değeri alır.
        
        boolean a = true;
        boolean b = false;
        System.out.println(a);
        System.out.println(b);
        
        
        
        
        
        
        
    }
    
}
