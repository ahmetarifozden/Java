
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int yas1 = scanner.nextInt();
        int yas2 = scanner.nextInt();
        int yas3 = scanner.nextInt();
        
        System.out.println("yas1 : " + yas1 + " yas2: " + yas2 + " yas3: " + yas3 );
        
        /*int yas = scanner.nextInt();
        scanner.nextLine(); // Dummy
        
        String isim = scanner.nextLine();
        
        System.out.println("Yaş: " + yas);
        System.out.println("İsim: " + isim);*/
        
        
        
        
        
    }
    
}
