
public class Main {
    public static void main(String[] args) {
        
       String a ="Java\tProgramlama\tDili";
       
        System.out.println();
       
        
       
        
        
        
        
        
        
        
    }
    
}
